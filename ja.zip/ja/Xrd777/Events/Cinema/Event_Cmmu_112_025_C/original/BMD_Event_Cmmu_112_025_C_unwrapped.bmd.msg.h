// Decompiled by Atlus Script Tools (2017-2021) © TGE
const int MSG_000_0_0                      = 0;
const int SEL_001_0_0                      = 1;
const int MSG_002_0_0                      = 2;
const int MSG_002_3_0                      = 3;
const int MSG_003_0_0                      = 4;
const int MSG_003_5_0                      = 5;
const int MSG_004_0_0                      = 6;
const int MSG_004_5_0                      = 7;
const int MSG_005_0_0                      = 8;
const int MSG_005_3_0                      = 9;
const int MND_006_0_0                      = 10;
const int MSG_007_0_0                      = 11;
const int MSG_008_0_0                      = 12;
const int MSG_009_0_0                      = 13;
const int MSG_010_0_0                      = 14;
const int MSG_011_0_0                      = 15;
const int MND_012_0_0                      = 16;
