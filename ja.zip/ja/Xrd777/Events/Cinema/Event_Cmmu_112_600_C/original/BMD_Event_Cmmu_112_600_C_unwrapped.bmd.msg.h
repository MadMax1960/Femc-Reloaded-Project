// Decompiled by Atlus Script Tools (2017-2021) © TGE
const int MSG_000_0_0                      = 0;
const int MSG_900_0_0                      = 1;
const int MSG_901_0_0                      = 2;
const int MSG_902_0_0                      = 3;
const int MND_001_0_0                      = 4;
const int MSG_002_0_0                      = 5;
const int MND_003_0_0                      = 6;
