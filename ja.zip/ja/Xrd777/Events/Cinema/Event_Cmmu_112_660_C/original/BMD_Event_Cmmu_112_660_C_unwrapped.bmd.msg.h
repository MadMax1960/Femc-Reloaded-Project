// Decompiled by Atlus Script Tools (2017-2021) © TGE
const int MSG_000_0_0                      = 0;
const int MND_001_0_0                      = 1;
const int MSG_002_0_0                      = 2;
const int MSG_002_5_0                      = 3;
const int MSG_002_7_0                      = 4;
const int MND_003_0_0                      = 5;
const int MSG_004_0_0                      = 6;
const int MSG_004_2_0                      = 7;
const int MSG_004_4_0                      = 8;
const int MSG_004_6_0                      = 9;
const int MSG_004_8_0                      = 10;
const int MND_005_0_0                      = 11;
const int MSG_006_0_0                      = 12;
const int MSG_006_3_0                      = 13;
const int MSG_006_5_0                      = 14;
const int MSG_006_7_0                      = 15;
const int MND_007_0_0                      = 16;
