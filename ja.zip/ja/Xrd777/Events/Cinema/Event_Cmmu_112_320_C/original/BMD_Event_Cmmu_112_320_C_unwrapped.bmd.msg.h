// Decompiled by Atlus Script Tools (2017-2021) © TGE
const int MSG_000_0_0                      = 0;
const int MSG_000_5_0                      = 1;
const int MSG_001_0_0                      = 2;
const int MSG_002_0_0                      = 3;
const int SEL_003_0_0                      = 4;
const int MSG_004_0_0                      = 5;
const int MND_005_0_0                      = 6;
const int MSG_006_0_0                      = 7;
const int MND_007_0_0                      = 8;
const int MSG_008_0_0                      = 9;
const int MND_009_0_0                      = 10;
const int MSG_010_0_0                      = 11;
const int MND_011_0_0                      = 12;
