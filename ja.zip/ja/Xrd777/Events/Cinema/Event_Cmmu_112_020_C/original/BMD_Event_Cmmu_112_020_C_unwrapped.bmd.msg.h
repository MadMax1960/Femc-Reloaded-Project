// Decompiled by Atlus Script Tools (2017-2021) © TGE
const int MSG_000_0_0                      = 0;
const int MSG_001_0_0                      = 1;
const int SEL_002_0_0                      = 2;
const int MSG_003_0_0                      = 3;
const int MSG_004_0_0                      = 4;
const int MSG_005_0_0                      = 5;
const int MSG_006_0_0                      = 6;
const int MSG_006_3_0                      = 7;
